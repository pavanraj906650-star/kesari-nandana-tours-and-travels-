package com.kesarinandana.tours;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout box;
    TextView total;
    EditText km;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        showCustomer();
    }

    TextView title(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(22); t.setTextColor(Color.rgb(20,70,130));
        t.setPadding(0,20,0,20); return t;
    }

    Button btn(String s) {
        Button b = new Button(this); b.setText(s); return b;
    }

    void base() {
        ScrollView sc = new ScrollView(this);
        box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(36,24,36,24); sc.addView(box); setContentView(sc);
    }

    void showCustomer() {
        base();
        box.addView(title("KESARI NANDANA\nTOURS AND TRAVELS"));
        box.addView(title("Customer Booking"));
        Spinner service = new Spinner(this);
        service.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
            new String[]{"Outstation","Local Package","Airport Pickup","Airport Drop"}));
        box.addView(service);
        EditText pickup = new EditText(this); pickup.setHint("Pickup location"); box.addView(pickup);
        EditText destination = new EditText(this); destination.setHint("Destination"); box.addView(destination);
        km = new EditText(this); km.setHint("Distance in km"); km.setInputType(2|8192); box.addView(km);

        Spinner vehicle = new Spinner(this);
        vehicle.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
            new String[]{"Sedan — ₹13/km + ₹300/day driver","SUV — ₹18/km + ₹500/day driver","Tempo Traveller — ₹22/km + ₹700/day driver"}));
        box.addView(vehicle);

        Button calc = btn("CALCULATE FARE"); box.addView(calc);
        total = new TextView(this); total.setTextSize(20); total.setPadding(0,20,0,20); box.addView(total);
        calc.setOnClickListener(v -> {
            double d=0; try { d=Double.parseDouble(km.getText().toString()); } catch(Exception e){}
            int pos=vehicle.getSelectedItemPosition();
            double rate=pos==0?13:pos==1?18:22, driver=pos==0?300:pos==1?500:700;
            double charge=Math.max(d,300)*rate;
            total.setText("Base fare: ₹"+(int)charge+"\nDriver: ₹"+(int)driver+
                "\nToll + Parking + State Tax: EXTRA\nTOTAL BEFORE EXTRAS: ₹"+(int)(charge+driver));
        });
        Button book=btn("REQUEST BOOKING"); box.addView(book);
        book.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Booking Requested")
            .setMessage("Your booking request has been recorded. Driver assignment can be connected in the next version.")
            .setPositiveButton("OK",null).show());
        Button driver=btn("DRIVER APP"); box.addView(driver);
        driver.setOnClickListener(v -> showDriver());
    }

    void showDriver() {
        base();
        box.addView(title("KESARI NANDANA — DRIVER"));
        box.addView(title("Driver Dashboard"));
        box.addView(btn("NEW BOOKING REQUEST"));
        box.addView(btn("ACCEPT BOOKING"));
        box.addView(btn("REJECT BOOKING"));
        box.addView(btn("ON THE WAY"));
        box.addView(btn("PICKED UP"));
        box.addView(btn("TRIP COMPLETED"));
        box.addView(title("Driver charges are included separately in customer fare."));
        Button back=btn("BACK TO CUSTOMER"); box.addView(back); back.setOnClickListener(v->showCustomer());
    }
}
